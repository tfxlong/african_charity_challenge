
&nbsp;  
***

&nbsp;        **WELCOME TO THE AFRICAN CHARITY CHALLENGE & THANK YOU FOR YOUR SUPPORT** 

***
&nbsp;   

**Here's how it works :**
=============
&nbsp;  

> | & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & &  | 
> |----------|:
| This is a challenge to support charities in Africa by supporting individual causes      You can sponsor a charity cause by selecting from the map and using Charity Coins       The eventual goal is to be able to sponsor all charity causes on the African map     |
| & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & &  | 
>
> **Charity Coins can be replenished in the following ways :** 
>
> - &nbsp;using your bank account budget
>       
> - &nbsp;requesting group sponsors 
>      
> - &nbsp;completing "work" to earn more *feature soon
> 
> _ _ _ _ 
> &nbsp;   **PROGRESS CAN BE SAVED FROM THE MAIN MENU AND LOADED AT A FUTURE DATE ON LAUNCH**

&nbsp;        